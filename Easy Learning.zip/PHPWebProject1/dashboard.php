<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./dashboard.css">
    <script language="javascript" src="libraries/p5.js"></script>
    <script language="javascript" src="libraries/p5.sound.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300&display=swap" rel="stylesheet">

    <title>Document</title>
</head>

    <body>
        <nav class="header">
            <div class="logo">
                <h1>Easy Learning &nbsp;| &nbsp;Dashboard</h1>
            </div>
        </nav>
        <div class="dashbord"></div>
        <main>
            <div class="todo">
                <h1 class="heading">My to-do List</h1>
                <div class="contanier">
                    <div id="todoMain">
                        <div>
                            <input type="text" name="newTask" id="addNewTask" placeholder="Enter New Task"
                                class="newItem">
                            <button type="submit" class="addBtn" onclick="addItem()">ADD</button>
                        </div>
                        <div class="toDoList" id="myList">
                        </div>
                    </div>

                    <div class="taskPanell">
                        <p>Total Task: <span id="totalTask">0</span></p>
                        <p>Panding Task: <span id="pandingTask">0</span></p>
                    </div>
                </div>
            </div>
            <div class="pomodoro">
                <h1 class="heading">My Pomodoro</h1>
                <div id="message"><span>Hurray It's Time To Take A Break of 5 min!!</span> <span
                        onclick="messageClear()">OK</span>
                </div>
                <div id="pomodoroMain">
                    <p id="timer">25 : 00</p>
                    <div id="btns">
                        <div>
                            <button id="startBtn">Start</button>
                            <button id="pauseBtn">Pause</button>
                            <button id="resumeBtn">Resume</button>
                        </div>
                        <div>
                            <button id="resetBtn">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="reward">
                <h1 class="heading">My Progress</h1>
                <div class="level"><span class="leveltext">Level</span><span id="levelnum">0</span></div>
                <div class="cover">
                    <div id="prgbar" class="progressbar"></div>
                </div>
                <div class="silverGold">
                    <div class="gold">
                        <span>Task Completed: </span>
                        <span id="maintaskcompleted">0</span>
                    </div>
                    <div class="silver">
                        <span>Time Studied: </span>
                        <span id="totalstudied">0 HOUR</span>
                    </div>
                </div>
            </div>
            <!-- MUSIC -->
            <div class="lofimusic">
                <h1 class="heading">Lo-Fi Music</h1>
                <span id="masterSongName">Warriyo - Mortals [NCS Release]</span>
                <input type="range" name="range" id="musicProgressBar" min="0" value="0" max="100">  
                <div class="icons">
                    <img src="musicPlayer/last.png" alt="previousBtn" id="previousBtn" height="44px" width="44px">
                    <img src="musicPlayer/play.png" alt="play" id="playBtn" height="44px" width="44px">
                    <img src="musicPlayer/next.png" alt="nextBtn" id="nextBtn" height="44px" width="44px">
                </div>
            </div>
        </main> 
        <form action="" method="post" class="footer-bar" id="footer-bar">
            <input type="email" id="emailSenderBox" name="emailSenderBox" />
            <button type="submit" name="email_btn" id="email_btn">Send Email</button>
        </form>
        <?php
            use PHPMailer\PHPMailer\PHPMailer;
            use PHPMailer\PHPMailer\SMTP;
            use PHPMailer\PHPMailer\Exception;

            if(isset($_POST['email_btn'])) {
                $mail = new PHPMailer(true);
                try {
                //Server settings
                    $mail->isSMTP();
                    $mail->Host= 'smtp.example.com';
                    $mail->SMTPAuth = true;
                    $mail->Username= 'user@example.com';
                    $mail->Password= 'secret';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port= 465;
                    $mail->setFrom('from@example.com', 'Mailer');
                    $mail->addAddress('joe@example.net', 'Joe User');
                    $mail->isHTML(true);
                    $mail->Subject = 'The Progress Mail';
                    $mail->Body    = htmlspecialchars('<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="color-scheme" content="light dark" />
    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300&display=swap" rel="stylesheet">
    <title></title>
    <style type="text/css" rel="stylesheet" media="all">
        * {
            font-family: "Barlow, sans-serif";
            margin: 0;
            padding: 0;
        }

        h1 {
            margin: 20px 0;
            text-align: center;
        }

        .img {
            background-color: white;
            width: 100%;
            padding: 20px 0;
            text-align: center;
            height: 256px;
        }

        p {
            margin: 20px 25px;
            text-align: center;
        }

        .level {
            color: wheat;
            font-size: 104px;
            margin: 0;
        }

        a {
            font-size: 12px;
        }

        @media (max-width: 768px) {
            p {
                text-align: left;
                margin: 12px 15px;
            }
        }
    </style>
</head>

<body>
    <h1>Easy Learn</h1>
    <div class="img">
        <img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.downloadclipart.net%2Flarge%2Freward-png-transparent-image.png&f=1&nofb=1"
            alt="" height="256px">
    </div>
    <h1>Congratulations, {username}</h1>
    <p>Your levels has been upgraded, Now your level is,</p>
    <p class="level">{userlevel}</p>

    <p>If you have any query, feel free to send a mail to us.</p>
    <p><a href="">Unsubscribe</a></p>
</body>'
                        );
                    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                    $mail->send();
                    echo 'Message has been sent';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            }
        ?>
        <script src="./dashboard.js"></script>
    </body>

</html>